function polygon = path_to_simple_polygon(path, width)
% -------------------------------------------------------------------------
% PATH_TO_SIMPLE_POLYGON    generates a simple polygon around path with 
% some input width.
%
% This function works only in 2D.
%
% If the path is self-intersecting or path is close enough to 
% self-intersection then resulting polygon is not guaranteed to be simple,
% i.e. it may be self-intersecting. Some of these cases are detected in
% this function but not all of them.
%
% Usage
%   polygon = PATH_TO_SIMPLE_POLYGON(path, width);
%
% Parameters
%   path        (2, n)      Sequence of 2D points representing the path.
%   width       (1, 1)      Width of polygon perpendicular to the path.
%
% Returns
%   polygon     (2, 2n)     Vertices of polygon representing inflated path.
%
% TODO
%   Needs revision, testing and refactoring
%
% Implementation
%   Mohamed Mustafa, September 2020
% -------------------------------------------------------------------------

% Extract informaiton
n_points = size(path, 2);
width_2 = width / 2;
v_2d = path(:, 2:end) - path(:, 1:end-1);   % direction of segments
[v_3d, v_len] = unit_vector([v_2d;      zeros(1, n_points-1)]);

% Special cases
if n_points == 1
    polygon = [];
    return
elseif n_points == 2
    R_ccw = rotationVector2Matrix([0 0 1] * pi / 2);
    t1 = R_ccw * v_3d * width_2;
    p_1 = repmat(t1(1:2, :), 1, 2) + path;
    
    R_cw = rotationVector2Matrix([0 0 1] * -pi / 2);
    t1 = R_cw * v_3d * width_2;
    p_2 = repmat(t1(1:2, :), 1, 2) + path;    

    polygon = [p_1, fliplr(p_2)];
    return
end

% 
% % Make sure path will not result in self-intersecting polygon. We look for
% % the closest distance between different segments in the path. Such
% % distance must not exceed the polygon width.
% all_comb = combnk(1:n_points-1, 2);         % all combinations
% valid_ind = abs(diff(all_comb, 1, 2)) ~=1;  % to avoid comparing consecutive line segments
% ind1 = all_comb(valid_ind, 1);
% ind2 = all_comb(valid_ind, 2);
% 
% line_segments = [path(:, 1:end-1);  v_2d];  % point-direction format
% ls_1 = line_segments(:, ind1);
% ls_2 = line_segments(:, ind2);
% 
% dist_ls_ls = zeros(size(ind1))';
% dist_ls_ls(~all(isfinite(intersect_two_lineSegs(ls_1, ls_2)), 1)) = inf;
% dist_ls_ep1 = distance_lineSeg_point(ls_1, ls_2(1:2, :));
% dist_ls_ep2 = distance_lineSeg_point(ls_1, ls_2(1:2, :) + ls_2(3:4, :));
% 
% closest_path_dist = min([dist_ls_ls, dist_ls_ep1, dist_ls_ep2]);
% if closest_path_dist < width
%     error('Invalid path! It can result in self-intersecting polygon.')
% end

% Find 1/2 angle and direction (cw or ccw) between consecutive vectors in 3D
v1 = v_3d(:, 1:end-1);      % first set of vectors
v2 = v_3d(:, 2:end);        % second set of vectors
angles_2 = angle_two_vectors(-v1, v2) / 2;    % angle to rotate
x = cross(v1, v2);
directions = sign(x(3, :));  % ccw: +ve,   cw: -ve

% This check below is different from the above as it checks consecutive
% line segments (no brute-force). And it's about checking projections of 
% polygon points on adjacent segments and whether that projection exceeds 
% the those segements.
% Make sure it's possible to have simple polygon given the path and width.
% Use `angles` and length of vectors find the maximum polygon width.
l = reshape(repmat(v_len, 2, 1), 1, []);
l = l(2:end-1);
th = reshape(repmat(angles_2, 2, 1), 1, []);
width_2_max = min(l .* tan(th));
if ~(is_close(width_2, width_2_max) || width_2 < width_2_max)
    % same as width_2 > width_2_max but takes precision into account
    warning(['Requested path width exceeds max possible width of '...
        num2str(width_2_max * 2) ' for input path! Max width is used instead.'])
    width_2 = width_2_max;
end

% Find angle for each vector to rotate (ccw)
angle_to_rotate_ccw = directions .* angles_2;
ind = directions < 0;
angle_to_rotate_ccw(ind) = wrapToPi(pi + angle_to_rotate_ccw(ind));
% Add pi/2 in the front to rotate first vector
angle_to_rotate_ccw = [pi / 2, angle_to_rotate_ccw];
% Length of rotated vectors
d_hat = width_2 ./ sin(angle_to_rotate_ccw);
% Find points at each side of the path
% Loop is done because of rotation matrix (think about vectorizing)
p_1 = zeros(2, n_points);
p_2 = p_1;
for i = 1:n_points - 1
    R_ccw = rotationVector2Matrix([0 0 1] * angle_to_rotate_ccw(i));
    t1 = R_ccw * v_3d(:, i) * d_hat(i);
    p_1(:, i) = t1(1:2) + path(:, i);
    
    R_cw = rotationVector2Matrix([0 0 1] * (angle_to_rotate_ccw(i) + pi));
    t2 = R_cw * v_3d(:, i) * d_hat(i);
    p_2(:, i) = t2(1:2) + path(:, i);
end
% consider the last point
R_ccw = rotationVector2Matrix([0 0 1] * pi / 2);
t1 = R_ccw * v_3d(:, end) * width_2;
p_1(:, end) = t1(1:2) + path(:, end);

R_cw = rotationVector2Matrix([0 0 1] * -pi / 2);
t1 = R_cw * v_3d(:, end) * width_2;
p_2(:, end) = t1(1:2) + path(:, end);

% Construct output polygon
polygon = [p_1, fliplr(p_2)];
end