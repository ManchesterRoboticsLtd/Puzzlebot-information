classdef Container < matlab.ui.container.internal.UIContainer
    %uix.Container  Container base class
    %
    %  uix.Container is base class for containers that extend uicontainer.
    
    %  Copyright 2009-2015 The MathWorks, Inc.
    %  $Revision: 1137 $ $Date: 2015-05-29 21:48:21 +0100 (Fri, 29 May 2015) $
    
end % classdef