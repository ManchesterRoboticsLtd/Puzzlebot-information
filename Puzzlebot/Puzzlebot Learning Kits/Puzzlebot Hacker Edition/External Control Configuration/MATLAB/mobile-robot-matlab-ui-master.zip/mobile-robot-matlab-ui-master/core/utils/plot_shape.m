function h = plot_shape(shape, varargin)
% -------------------------------------------------------------------------
% PLOT_SHAPE    plot a shape on figure either in 2D or 3D.
%
% Usage
%   h = PLOT_SHAPE(shape, varargin);
%
% Parameters
%   shape       (1, 1)  Struct with the `type` mandatory field.
%                       `color` field is optional for all types.
%                       Optional fields depend on the shape. Look below for
%                       more detail.
%   varargin    sequence of char and arrays with following options:
%                       'transformation' --> (4, 4) rigid transformation,
%                       'alpha' --> color transparency parameter.
%
% Returns
%   h           (1, 1)  plot handle.
%
% TODO
%   Think about efficient ploting when having an array of similar type.
%
% Implementation
%   Mohamed Mustafa, July 2020
% -------------------------------------------------------------------------

% Default values
T = eye(4);
alpha = 0.2;
var_ind = 1;
while var_ind <= length(varargin)
    switch varargin{var_ind}
        case 'transformation'
            % Read json-file
            T = varargin{var_ind + 1};
            var_ind = var_ind + 2;  % index to next variable
        case 'alpha'
            alpha = varargin{var_ind + 1};
            var_ind = var_ind + 2;  % index to next variable
        otherwise
            error(['Unexpected option: `' varargin{var_ind} '`!'])
    end
end
if isfield(shape, 'color')
    col = shape.color;
else
    col = 'red';
end

if strcmp(shape.type, 'cylinder')
    % Sanity check
    required_fields = {'z_limits', 'diameter'};
    missing_ind = ~isfield(shape, required_fields);
    if any(missing_ind)
        error(['Missing field: `' required_fields{find(missing_ind, 1, 'first')} '` for shape of type: `' shape.type '`!'])
    end
    % Create cylinder in local reference frame
    [X, Y, Z] = cylinder(shape.diameter/2, 20);
    Z(1, :) = ones(size(Z(1, :))) * shape.z_limits(1);
    Z(2, :) = ones(size(Z(1, :))) * shape.z_limits(2);
    % Transform to `T` frame
    t1 = homog2cart(T*cart2homog([X(:) Y(:) Z(:)]'));
    X = reshape(t1(1, :), 2,[]);
    Y = reshape(t1(2, :), 2,[]);
    Z = reshape(t1(3, :), 2,[]);
    % Plot with transparency
    h(1) = surf(X, Y, Z, 'FaceColor', col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
    h(2) = patch(X', Y', Z', col, 'FaceAlpha', alpha, 'EdgeColor','black');
elseif strcmp(shape.type, 'box')
    % Sanity check
    required_fields = {'x_limits', 'y_limits', 'z_limits'};
    missing_ind = ~isfield(shape, required_fields);
    if any(missing_ind)
        error(['Missing field: `' required_fields{find(missing_ind, 1, 'first')} '` for shape of type: `' shape.type '`!'])
    end
    % Create box in local reference frame
    X = repmat([shape.x_limits fliplr(shape.x_limits) shape.x_limits(1)], [2, 1]);
    Y = repmat([reshape(repmat(shape.y_limits, [2, 1]), 1, []) shape.y_limits(1)], [2, 1]);
    Z = repmat(shape.z_limits', [1, 5]);
    % Transform to `T` frame
    t1 = homog2cart(T*cart2homog([X(:) Y(:) Z(:)]'));
    X = reshape(t1(1, :), 2,[]);
    Y = reshape(t1(2, :), 2,[]);
    Z = reshape(t1(3, :), 2,[]);
    % Plot with transparency
    h(1) = surf(X, Y, Z, 'FaceColor', col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
    h(2) = patch(X', Y', Z', col, 'FaceAlpha', alpha, 'EdgeColor','black');
elseif strcmp(shape.type, 'prism')
    
elseif strcmp(shape.type, 'circle')
    % Sanity check
    required_fields = {'center', 'diameter'};
    missing_ind = ~isfield(shape, required_fields);
    if any(missing_ind)
        error(['Missing field: `' required_fields{find(missing_ind, 1, 'first')} '` for shape of type: `' shape.type '`!'])
    end
    % plot circle
    theta = linspace(0, 2*pi, 21)';
    x = shape.diameter / 2 * cos(theta) + shape.center(1);
    y = shape.diameter / 2 * sin(theta) + shape.center(2);
    h = fill(x, y, col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
elseif strcmp(shape.type, 'point')
    % Sanity check
    required_fields = {'coordinates'};
    missing_ind = ~isfield(shape, required_fields);
    if any(missing_ind)
        error(['Missing field: `' required_fields{find(missing_ind, 1, 'first')} '` for shape of type: `' shape.type '`!'])
    end
    % plot point
    h = plot(shape.coordinates(1,:),shape.coordinates(2,:),'rp','MarkerSize',20,'MarkerFaceColor',col);
elseif strcmp(shape.type, 'polygon')
    % Sanity check
    required_fields = {'vertices'};
    missing_ind = ~isfield(shape, required_fields);
    if any(missing_ind)
        error(['Missing field: `' required_fields{find(missing_ind, 1, 'first')} '` for shape of type: `' shape.type '`!'])
    end
    % plot polygon
    h = fill(shape.vertices(1,:), shape.vertices(2,:), col, 'FaceAlpha', alpha, 'EdgeColor', 'none');
else
    error(['Plotting shape of type`' shape.type '` is not implemented!'])
end
end