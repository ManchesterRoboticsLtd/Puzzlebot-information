function angle = simulate_servo_motor(sensor, angle)
% -------------------------------------------------------------------------
% SIMULATE_SERVO_MOTOR    find the new angle of a servo motor based on
% input angle signal.
%
% Usage
%   angle = SIMULATE_SERVO_MOTOR(sensor, angle);
%
% Parameters
%   sensor          (1, 1)  ComponentClass object with type `lidar-2d`
%   angle           (1, 1)  Input angle in radian.
%
% Returns
%   angle           (1, 1)  Output angle.
%
% Implementation
%   Mohamed Mustafa, August 2020
% -------------------------------------------------------------------------

% Sanity check
if ~strcmp(sensor.type, 'servo-motor')
    error(['Invalid sensor type (' sensor.type ')! Expected: servo-motor'])
end
angle_limits = sensor.angle_limits;
% Convert angles to radian if necessary
try
    if strcmp(sensor.angle_unit, 'degree')
        angle_limits = deg2rad(angle_limits);
    end
catch
end
% Consider hardware limits
angle = clip(wrapToPi(angle), angle_limits(1), angle_limits(2));
end