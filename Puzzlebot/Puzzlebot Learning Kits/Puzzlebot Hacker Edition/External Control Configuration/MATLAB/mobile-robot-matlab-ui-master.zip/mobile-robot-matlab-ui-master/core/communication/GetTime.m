function time = GetTime(com_data)
    
   time = toc(com_data.t_start)+com_data.t_offset;

return