function parameters = varargin_to_parameters(varargin)
% TODO: Add doc-string
% length of varargin must be even number

varargin = varargin{1};     % because it's passed over matlab is putting it in cell array
% Decode input parameters
var_ind = 1;
parameters = [];    % initialize
while var_ind <= length(varargin)
    field_name = varargin{var_ind};
    if ischar(field_name)
        if var_ind + 1 > length(varargin)
            error(['Missing option value after `' field_name '`!'])
        end
        parameters.(field_name) = varargin{var_ind + 1};
    else
        error(['Leading option is not a char: `' class(varargin{var_ind}) '`!'])
    end
    var_ind = var_ind + 2;  % index to next variable
end
end