function [E_normalized, unit_readings] = simulate_reflectance(sensor,...
    world, T_sensor_world)
% -------------------------------------------------------------------------
% SIMULATE_REFLECTANCE    find expected value of array of reflectance
% sensors in its local frame when the sensors interacts with the world.
%
% Simulation assumes objects in the world to be 2D with no height, and it
% only works with polygon shapes.
%
% Usage
%   [E_normalized, unit_readings] = ...
%       SIMULATE_REFLECTANCE(sensor, world, T_sensor_world);
%
% Parameters
%   sensor          (1, 1)  ComponentClass object with type `reflectance`
%   world           (1, 1)  WorldClass object
%   T_sensor_world  (4, 4)  Transformation from sensor to world (optional)
%                           If this parameter is not present it's replaced
%                           by sensor.transformation
%
% Returns
%   E_normalized    (1, 1)  Expected value of the reflectance readings with
%                           respect to their position in the sensor local
%                           frame. This expectation is normalized such
%                           that range is [-1, 1].
%   unit_readings	(1, n)  Individual unit readings with n = num_units.
%                           The range is either [0, 1], or if available in
%                           the JSON-file [min_value, max_value].
%
% Implementation
%   Mohamed Mustafa, August 2020
% -------------------------------------------------------------------------

% Sanity check
if ~strcmp(sensor.type, 'reflectance')
    error(['Invalid sensor type (' sensor.type ')! Expected: reflectance'])
end
% Default values
if nargin < 3
    T_sensor_world = sensor.transformation;
end
try
    kernel_size = sensor.interference_kernel_size;
catch
    kernel_size = 3;
end
% Generate LED units in sensor frame
lims = sensor.shape.x_limits;
x = linspace(lims(1), lims(2), sensor.num_units);
units_3d = [x;  zeros(2, sensor.num_units)];
% Transform units to world frame
units_3d_w = homog2cart(T_sensor_world * cart2homog(units_3d));
% Find intersection with world polygons
ind_in = false(1, sensor.num_units);   % initalization (for the case of multiple polygons in world)
for i = 1:length(world.shapes)
    if strcmp(world.shapes{i}.type, 'polygon')
        ind_in = or(ind_in, is_point_inside_simple_polygon(units_3d_w(1:2, :), world.shapes{i}.vertices));
    end
end
% Add interference noise (fixed size)
unit_readings = conv(double(ind_in), ones(1, kernel_size)/kernel_size, 'same');
% Expected value between -1 and 1
% Negative sign is for turning convension
E_normalized = -sum(unit_readings .* linspace(-1, 1, sensor.num_units));
if ~is_close(E_normalized, 0)
    E_normalized = E_normalized / sum(unit_readings);
end
% Consider min and max values
try
    unit_readings = sensor.min_value + (sensor.max_value - sensor.min_value) .* unit_readings;
catch
end
end