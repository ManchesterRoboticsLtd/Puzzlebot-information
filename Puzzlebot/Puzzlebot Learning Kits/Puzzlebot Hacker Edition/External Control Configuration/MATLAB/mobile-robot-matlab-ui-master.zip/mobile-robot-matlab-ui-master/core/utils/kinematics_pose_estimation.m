function [pose_new, Dp_p, Dp_w, omegas_rhr] = ...
    kinematics_pose_estimation(robot, pose_old, d_t, omegas_map)
% -------------------------------------------------------------------------
% KINEMATICS_POSE_ESTIMATION    computes the robot new pose using its
% kinematics model.
% 
% Robot can have any wheel configuration, and it is assmued moving in 2D
% world (ramps are not supported).
%
% Not all wheels contribute to this kinematics model! If the following
% conditions apply then the wheel affects the model:
%   - wheel is driven by a DC-motor. Compounded motor configuration, e.g.
%     DC motor connected to another DC motor in series is not considered.
%     Only the immediate parent controls the wheel angular velocity. Such
%     wheel is called active_wheel.
%   - wheel must have the normal vector to its plane perpendicular to the
%     world z-axis, that is, wheel must have vertical contact with the
%     world xy-plane. This condition might change over time especially when
%     the drive motor is steered by another motor. 
%
% Notes: 
%   - Other motors (DC or servo) can be connected to the drive DC-motor but
%     they must be used for steering only, i.e. they rotate the drive motor
%     around the world z-axis.
%   - The z-position of the wheel is ignored, i.e. it's assumed all valid
%     wheels are in contact with the world xy-plane.
%
% This function uses robot object to ONLY extract wheel initial properties 
% and transfromations with respect to the robot local frame. Other robot
% properties, such as transformation or motor velocities, are not used to
% compute the new pose. This is because it's possible to use this function
% for dead reckoning localization where such class keeps track of its own
% representation of pose. Moreover, when physical/real robot is used
% `robot.transformation` is not necessarily updated, and wheel velocity is
% measured using encoder, if available.
%
% Usage
%   [pose_new, Dp_p, Dp_w, omegas_rhr] = ...
%       KINEMATICS_POSE_ESTIMATION(robot, pose_old, d_t, omegas_map);
%
% Parameters
%   robot    	(1, 1)  RobotClass object.
%   pose_old	(3, k)  Robot old pose in 2D world (x, y, th) with respect
%                       to  world reference frame. k is the number of poses
%                       to update.
%   d_t         (1, 1)  Time step at which wheel angular velocities are
%                       assumed constant.
%   omegas_map	(1, 1)  containers.Map object (hash table) with keys
%                       storing either wheel index or wheel label, and
%                       values storing angular velocities. The rotation 
%                       convension of each wheel is determined from robot
%                       object and defined in the robot JSON-file. This map
%                       does not have to include all active wheels. Missing
%                       wheels are assigned 0 angular velocities.
%
% Returns
%   pose_new    (3, k)      Robot new pose in 2D world (x, y, th) with
%                           resepect to  world reference frame.
%   Dp_p        (3, 3, k)   Jacobian of pose_new wrt pose_old (x, y, th).
%   Dp_w        (3, n, k)   Jacobian of pose_new wrt robot_velocities
%                           (v_x, v_y, w), where n is the number of valid
%                           active wheels.
%   omegas_rhr  (n, 1)      Angular velocities of all valid active wheels
%                           (even those that are not in omegas_map) in rhr
%                           rotation convension. This output is congruent
%                           with Dp_w in terms of entries order (this order
%                           is not present in omegas_map becuase it's a
%                           hash table), and both are needed to compute the
%                           motion additive noise covariance in
%                           localization.
%
% Reference
%   Introduction to Autonomous Mobile Robots (Chapter 3)
%   https://www.dis.uniroma1.it/~oriolo/amr/slides/Localization1_Slides.pdf
%   https://robotacademy.net.au/lesson/derivative-of-a-rotation-matrix/
%
% Implementation
%   Mohamed Mustafa, August 2020
% -------------------------------------------------------------------------

% Sanity Checks
[d, k] = size(pose_old);
if d ~= 3
    error('Invalid pose_old!')
end
if ~isa(omegas_map, 'containers.Map')
    error('omegas_map is not of class containers.Map!')
end
% This check is duplicated in RobotClass but it's necessary here when
% using this function for localization.
try
    active_wheel_inds = robot.active_wheel_inds;
catch
    % Find active wheel indices
    active_wheel_inds = [];
    for i = 2:robot.components_tree.nnodes
        if strcmp(robot.components_tree.get(i).category, 'wheel')
            % Make sure it's connected to a DC motor
            p = robot.components_tree.getparent(i);
            if strcmp(robot.components_tree.get(p).type, 'dc-motor')
                active_wheel_inds = [active_wheel_inds, i];
            end
        end
    end
end
% initialization
J1 = [];	J2_diag = [];	C1 = [];	omegas_rhr = [];
for ind = active_wheel_inds
    wheel_comp = robot.components_tree.get(ind);
    T_wheel_robot = robot.component_to_robot_world_transfromation(ind);
    wheel_normal_in_Rf = T_wheel_robot(1:3, 1:3) * [0, 0, 1]';  % the right-most vector is wheel plane normal in wheel local frame
    % Make sure wheel_normal_in_R is orthogonal to world z-axis (wheel has vertical contact with the xy-plane)
    if ~is_close(dot(wheel_normal_in_Rf, [0, 0, 1]), 0)
        continue        % Ignore wheel
    end
    % Create for each wheel:
    %    - rolling constraint (J1 and J2 matrices), and
    %    - sliding constraint (C1 matrix)
    alpha_beta_sum = atan2(wheel_normal_in_Rf(2), wheel_normal_in_Rf(1));
    [alpha, l] = cart2pol(T_wheel_robot(1, 4), T_wheel_robot(2, 4));
    beta = alpha_beta_sum - alpha;
    if strcmp(wheel_comp.type, 'standard')
        J1 = [J1; [sin(alpha_beta_sum),     -cos(alpha_beta_sum),   -l * cos(beta)]];
        J2_diag = [J2_diag,   wheel_comp.shape.diameter / 2];
        C1 = [C1; [cos(alpha_beta_sum),     sin(alpha_beta_sum),    l * sin(beta)]];
    elseif strcmp(wheel_comp.type, 'swedish')
        gamma = wheel_comp.gamma;
        % Convert angles to radian if necessary
        try
            if strcmp(wheel_comp.angle_unit, 'degree')
                gamma = deg2rad(gamma);
            end
        catch
        end
        % There is no sliding constraint
        J1 = [J1; [sin(alpha_beta_sum + gamma),     -cos(alpha_beta_sum + gamma),   -l * cos(beta + gamma)]];
        J2_diag = [J2_diag,   wheel_comp.shape.diameter / 2 * cos(gamma)];
    else
        error(['Wheel type: ' wheel_comp.type, ' is not supported!'])
    end
    % wheel angular velocity. Priority to wheel index over wheel label
    if isKey(omegas_map, ind)
        omega = omegas_map(ind);
    elseif isKey(omegas_map, wheel_comp.label)
        omega = omegas_map(wheel_comp.label);
    else
        omega = 0;
    end
    % Make sure omega is always in rhr
    try
        if ~strcmp(wheel_comp.rotation_convension, 'rhr')
            omega = -omega;
        end
    catch
    end
    omegas_rhr = [omegas_rhr; omega];
end
% Transformation matrix F from wheel velocities:  (omega_1, omega_2, ..., omega_n)
%                           to robot velocities:  (v_x, v_y, w)
J2 = [diag(J2_diag); zeros(size(C1, 1), length(J2_diag))];
F = [J1; C1] \ J2;      % This can be used for getting derivative for noise generation
% Robot local velocities   (v_x, v_y, w)
robot_velocities = F * omegas_rhr;
% Check if all C1 are satisfied (equal to zero) otherwise robot is skidding
if ~isempty(C1)
    C1_hat = C1 * robot_velocities;
    if ~all_close(C1_hat, 0)
        warning('At least one wheel is not satisfying sliding constraint!')
    end
end
% Initialize outputs because of the for-loop
pose_new = zeros(3, k);
if nargout > 1
    S = vec2skewSymMat([0, 0, 1]);      % Skew symmetric matrix for rotation about the z-axis
    Dp_p = repmat(eye(3), [1, 1, k]);
    Dp_v = zeros(3);        % faster than using blkdiag
    Dp_w = zeros(3, length(omegas_rhr), k);
end
% Loop seems faster than vectorization (check performence test in playground)
straight = is_close(robot_velocities(3), 0, 1e-6);
for i = 1:k
    % Pose increment (exact solution using integration by substitution)
    if straight
        % w = 0 --> Use Eular method
        % Note that s_dot = Rot(theta) * robot_velocities
        Rot = rotationVector2Matrix([0, 0, pose_old(3, i)]);
        pose_increment = Rot * robot_velocities * d_t;
    else
        % w ~= 0 --> Integration by substitution
        theta_old = pose_old(3, i);
        delta_theta = robot_velocities(3) * d_t;
        theta_new = theta_old + delta_theta;
        cos_new = cos(theta_new);
        sin_new = sin(theta_new);
        diff_cos = cos_new - cos(theta_old);
        diff_sin = sin_new - sin(theta_old);
        M = [diff_sin,  diff_cos;   -diff_cos,  diff_sin] / robot_velocities(3);
        delta_xy = M * robot_velocities(1:2);
        pose_increment = [delta_xy; delta_theta];
    end
    % Compute new pose
    pose_new(:, i) = pose_old(:, i) + pose_increment;
    % Compute Jacobians (closed form)
    if nargout > 1
        % Jacobian of pose_new wrt pose_old (Dp_p)
        Dp_p(:, 3, i) = Dp_p(:, 3, i) + S * pose_increment;   % use rotation matrix derivative property
        % Jacobian of pose_new wrt robot_velocities (Dp_v)
        if straight
            % w = 0
            Dp_v = Rot * d_t;
        else
            % w ~= 0
            Dp_v(1:2, 1:2) = M;     % faster than using blkdiag
            Dp_v(3, 3) = d_t;
            Rot_new = [cos_new,   -sin_new;   sin_new,    cos_new];            
            Dp_v(1:2, 3) = (Rot_new * d_t - M) * robot_velocities(1:2) / robot_velocities(3);
        end
        % Jacobian of pose_new wrt omegas_rhr (Dp_w)
        Dp_w(:, :, i) = Dp_v * F;
    end
end
end