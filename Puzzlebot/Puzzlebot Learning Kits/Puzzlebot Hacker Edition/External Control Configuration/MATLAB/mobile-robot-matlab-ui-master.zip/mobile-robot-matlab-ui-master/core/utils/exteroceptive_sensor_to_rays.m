function [p, v, angle_diff] = ...
    exteroceptive_sensor_to_rays(sensor, T_sensor_world, dimension, n_angles)
% -------------------------------------------------------------------------
% EXTEROCEPTIVE_SENSOR_TO_RAYS    constructs a set of rays from sensor
% origin to its field of view based on sensor's properties.
%
% Usage
%   [p, v, angle_diff] = EXTEROCEPTIVE_SENSOR_TO_RAYS(sensor, T_sensor_world, dimension);
%
% Parameters
%   sensor          (1, 1)  ComponentClass object
%   T_sensor_world  (4, 4)  Transformation from sensor to world (optional).
%                           If this parameter is not present it's replaced
%                           by sensor.transformation
%   dimension       (1, 1)  Rays dimension (optional). Possible values: {2, 3}
%   n_angles        (1, 1)  Number of points to generate for Sonar case
%                           only.
%
% Returns
%   p               (d, 1)  Rays starting point where d = dimesnion
%   v               (d, n)  Rays direction unit vectors
%   angle_diff      (1, 1)  Difference between consecutive generated
%                           angles. This output is needed for point
%                           primitive in ray_cast function.
%
% Implementation
%   Mohamed Mustafa, August 2020
% -------------------------------------------------------------------------

% Default values
if nargin < 3
    dimension = 2;
    if nargin < 2
        T_sensor_world = obj.transformation;
    end
end
% Sanity Check
if dimension < 2 || dimension > 3
    error(['Invalid dimension (' num2str(dimension) ')!'])
end
% Consider different sensor types
if strcmp(sensor.type, 'lidar-2d')
    n_angles = round(sensor.angle_span / sensor.angle_resolution);
    angles = linspace(-sensor.angle_span/2, sensor.angle_span/2, n_angles);
    % Convert angles to radian if necessary
    try
        if strcmp(sensor.angle_unit, 'degree')
            angles = deg2rad(angles);
        end
    catch
    end
    % direction vectors in sensor reference frame (3D)
    v = [cos(angles);   sin(angles);    zeros(1, n_angles)];
    % Transform ray direction vectors to world frame (3D)
    p = T_sensor_world(1:3, 4);             % ray starting point
    v = T_sensor_world(1:3, 1:3) * v;       % ray directions vectors
    % Consider the dimension parameter
    if dimension == 2
        p = p(1:2);
        v = unit_vector(v(1:2, :));
    end
    % Compute angle difference
    angle_diff = abs(angles(2) - angles(1));
elseif strcmp(sensor.type, 'sonar')
    % Default values
    if nargin < 4
        if dimension == 2
            n_angles = 10;      % number of rays to generate
        elseif dimension == 3
            n_angles = 100;     % number of rays to generate
        end
    end
    sonar_angle_span = sensor.angle_span;
    % Convert angles to radian if necessary
    try
        if strcmp(sensor.angle_unit, 'degree')
            sonar_angle_span = deg2rad(sonar_angle_span);
        end
    catch
    end
    if dimension == 2
        sesnor_local_axis = [0, 0, 1]';    % Refer to documentation for sensor local frame.
        v_proj = T_sensor_world(1:3, 1:3) * sesnor_local_axis;   % transform center axis of sonar to world frame
        angle_with_x_axis = atan2(v_proj(2), v_proj(1));    % angle on xy-plane
        angles = linspace(angle_with_x_axis - sonar_angle_span / 2, ...
                          angle_with_x_axis + sonar_angle_span / 2, ...
                          n_angles);
        % direction vectors in world frame
        v = [cos(angles);   sin(angles)];   % ray directions vectors
        p = T_sensor_world(1:2, 4);         % ray starting point
    elseif dimension == 3
        n_rotations = 5;    % number of rotations including final outer circle
        % Create a spiral with final outer circle to simulate sonar cone
        r_max = sin(sonar_angle_span / 2);
        n_angles_2 = round(n_angles / (n_rotations - 1));
        n_angles_1 = n_angles - n_angles_2;
        angles_1 = linspace(0, (n_rotations - 1) * 2 * pi, n_angles_1);
        angles_2 = linspace(0, 2 * pi, n_angles_2);
        r_1 = angles_1 / ((n_rotations - 1) * 2 * pi) * r_max;
        r_2 = repmat(r_max, [1, n_angles_2]);
        angles = [angles_1, angles_2];
        r = [r_1, r_2];
        x = r .* cos(angles);
        y = r .* sin(angles);
        z = ones([1, n_angles]);
        % direction vectors in sensor reference frame (3D)
        v = [x; y; z];
        % Transform ray direction vectors to world frame (3D)
        p = T_sensor_world(1:3, 4);             % ray starting point
        v = T_sensor_world(1:3, 1:3) * v;       % ray directions vectors
    end
    % Compute angle difference
    angle_diff = abs(angles(2) - angles(1));
else
    error(['Invalid sensor type (' sensor.type ')!'])
end
end