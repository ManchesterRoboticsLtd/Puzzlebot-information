function my_alg = add_plot(my_alg, str)
% Add plot to be displayed in the main UI figure.

if isKey(my_alg, 'plots')
    P = my_alg('plots');
    P{end + 1} = str;
    my_alg('plots') = P;
else
    my_alg('plots') = str;
end
end