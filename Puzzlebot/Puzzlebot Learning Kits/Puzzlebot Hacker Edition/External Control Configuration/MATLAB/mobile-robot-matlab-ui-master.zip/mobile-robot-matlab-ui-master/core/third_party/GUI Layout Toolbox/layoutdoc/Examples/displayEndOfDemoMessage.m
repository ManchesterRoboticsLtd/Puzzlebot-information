function displayEndOfDemoMessage(filename)
% Dummy function - do nothing.
%
% Copyright 2009-2013 The MathWorks, Inc.
