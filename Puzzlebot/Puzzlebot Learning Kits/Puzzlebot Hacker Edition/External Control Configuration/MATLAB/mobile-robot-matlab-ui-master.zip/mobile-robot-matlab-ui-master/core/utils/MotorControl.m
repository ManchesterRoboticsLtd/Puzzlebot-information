classdef MotorControl < handle
    %UNTITLED Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
         
        Kp = 0.03;
        Ti = 0.1;
        Td = 0;
        br = 1;
        err_int,der,err;
    end
    
    methods
        function obj=MotorControl()
            obj.err=0;
            obj.err_int=0;
        end
        function u=Control(obj,r,y,dt)
            er = r-y;
            obj.der = (er-obj.err)/dt;
            obj.err_int = obj.err_int+er*dt;
            u = obj.Kp*((obj.br*r-y)+1/obj.Ti*obj.err_int);
            obj.err = er;
        end
    end
    
end

