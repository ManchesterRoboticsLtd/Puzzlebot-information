function transformation3d = pose2d_to_transformation3d(pose2d)
% -------------------------------------------------------------------------
% POSE2D_TO_TRANSFORMATION3D    converts pose in 2D to 3D transfromation
% matrix.
%
% 2D pose is a 3D vector with (x, y, theta). This function creates rotation
% about the z-axis and adds 0 to the extra z dimension.
%
% Usage
%   transformation3d = POSE2D_TO_TRANSFORMATION3D(pose2d);
%
% Parameters
%   pose2d              (3, 1)  2D pose in xy-plane.
%
% Returns
%   transformation3d    (4, 4)  Transformation matrix of robot 3D pose.
%
% Implementation
%   Mohamed Mustafa, September 2020
% -------------------------------------------------------------------------

% Sanity Checks
if length(pose2d) ~= 3
    error('Invalid pose in 2D!')
end
% Construct transformation3d
pose2d = pose2d(:);     % make sure pose2d is a column vector
transformation3d = eye(4);
transformation3d(1:2, 4) = pose2d(1:2);
%transformation3d(1:3, 1:3) = rotationVector2Matrix([0, 0, pose2d(3)]);     % can be slow
c = cos(pose2d(3));
s = sin(pose2d(3));
transformation3d(1:2, 1:2) = [c -s;s c];
end