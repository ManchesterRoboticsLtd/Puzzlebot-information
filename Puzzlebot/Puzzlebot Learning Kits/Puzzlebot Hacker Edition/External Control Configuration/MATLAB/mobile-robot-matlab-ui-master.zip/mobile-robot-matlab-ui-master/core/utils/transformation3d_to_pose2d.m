function pose2d = transformation3d_to_pose2d(transformation3d)
% -------------------------------------------------------------------------
% TRANSFORMATION3D_TO_POSE2D    converts 3D transformation matrix to pose
% in 2D.
%
% 2D pose is a 3D vector with (x, y, theta). Basically this function
% projects 3D transfromation matrix onto xy-plane.
%
% Usage
%   pose2d = TRANSFORMATION3D_TO_POSE2D(transformation3d);
%
% Parameters
%   transformation3d    (4, 4)  Transformation matrix of robot 3D pose.
%
% Returns
%   pose2d              (3, 1)  2D pose in xy-plane.
%
% Implementation
%   Mohamed Mustafa, September 2020
% -------------------------------------------------------------------------

% Sanity Checks
if ~is_rigid_transformation(transformation3d, 3)
    error('Invalid transformation matrix in 3D!')
end
% Construct pose2d
pose2d(1:2, 1) = transformation3d(1:2, 4);	% xy
rotation_vector = rotationMatrix2Vector(transformation3d(1:3, 1:3));
[ax, angle] = unit_vector(rotation_vector);
pose2d(3) = angle * sign(ax(3));            % theta
end