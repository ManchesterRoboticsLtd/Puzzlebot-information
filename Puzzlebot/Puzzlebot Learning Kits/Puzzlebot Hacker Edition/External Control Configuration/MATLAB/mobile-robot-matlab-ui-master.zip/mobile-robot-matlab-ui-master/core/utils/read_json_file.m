function json = read_json_file(json_fname)
%READ_JSON_FILE    Read JSON file.
% json = READ_JSON_FILE(json_fname) returns a sturct with contents of the
% JSON file.
%
% Mohamed Mustafa, July 2020

fid = fopen(json_fname);
str = char(fread(fid,inf)');
fclose(fid);
json = parse_json(str);
end