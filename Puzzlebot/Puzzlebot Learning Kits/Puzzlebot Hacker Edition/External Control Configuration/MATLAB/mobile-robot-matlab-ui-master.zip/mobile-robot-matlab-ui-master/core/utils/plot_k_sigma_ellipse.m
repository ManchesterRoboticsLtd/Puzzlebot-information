function h = plot_k_sigma_ellipse(cov, mu, k, col, np)
% -------------------------------------------------------------------------
% PLOT_K_SIGMA_ELLIPSE    plot covariance error ellipse in 2D.
%
% Usage
%   h = PLOT_K_SIGMA_ELLIPSE(cov, mu, conf, col, np);
%
% Parameters
%   cov     (2, 2)  Covariance matrix in 2D.
%   mu      (2, 1)  Mean in 2D.
%   k       (1, 1)  Number of sigmas to include, e.g. 3
%   col     (1, 1)  Color of the plot
%   np      (1, 1)  Number of points to use in plotting.
%
% Returns
%   h       (1, 1)  plot handle.
%
% Reference
%   https://commons.wikimedia.org/wiki/File:MultivariateNormal.png
%
% Implementation
%   Mohamed Mustafa, December 2020
% -------------------------------------------------------------------------

% Default values
if nargin < 5
    np = 50;
    if nargin < 4
        col = 'b';
        if nargin < 3
            k = 3;
            if nargin < 2
                mu = [0 0];
            end
        end
    end
end
% Make sure covariance is symmetric in 2D
[r, c] = size(cov);
dim_cond = (r == c) && (r == 2);
sym_cond = all_close(cov, cov');
if ~(dim_cond && sym_cond)
    error('Covariance matrix is either not symmetric or not in 2D')
end
% Compute eigenvalues of cov
[~, D] = eig(cov);
m = min(diag(D));
if is_close(m, 0)
    h = [];
    return
elseif m < 0
    error('Covariance matrix is not positive semi-definite!')
end
% Find ellipse points centered at origin
t = linspace(0, 2*pi, np);
L = chol(cov,'lower');
C = [cos(t) ; sin(t)];
pts = k * L * C;
% Translate points using mean mu
pts = bsxfun(@plus, pts, mu(:));
% Plot ellipse
h = plot(pts(1, :), pts(2, :), [col '-']);
end