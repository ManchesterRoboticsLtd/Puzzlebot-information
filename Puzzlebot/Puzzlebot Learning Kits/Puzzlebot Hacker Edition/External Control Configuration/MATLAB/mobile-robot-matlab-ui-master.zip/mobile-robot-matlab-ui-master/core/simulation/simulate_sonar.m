function depth = simulate_sonar(sensor, world, T_sensor_world)
% -------------------------------------------------------------------------
% SIMULATE_SONAR    find depth value when sonar interacts with the world.
%
% Simulation is done in 2D or 3D depending on the dimension of the world.
%
% Usage
%   depth = SIMULATE_SONAR(sensor, world, T_sensor_world);
%
% Parameters
%   sensor          (1, 1)  ComponentClass object with type `sonar`
%   world           (1, 1)  WorldClass object
%   T_sensor_world  (4, 4)  Transformation from sensor to world (optional)
%                           If this parameter is not present it's replaced
%                           by sensor.transformation
%
% Returns
%   depth           (1, 1)  depth of the nearest object to the sensor
%                           within its conic region
%
% Implementation
%   Mohamed Mustafa, August 2020
% -------------------------------------------------------------------------

% Sanity check
if ~strcmp(sensor.type, 'sonar')
    error(['Invalid sensor type (' sensor.type ')! Expected: sonar'])
end
% Default values
if nargin < 3
    T_sensor_world = sensor.transformation;
end
% Create rays in world frame
[p, v, angle_diff] = exteroceptive_sensor_to_rays(sensor, T_sensor_world, world.dimension);
rays = [repmat(p, 1, size(v, 2));   v];
% Apply ray casting
depth = ray_cast(rays, world.primitives, 'dimension', world.dimension, 'angle_threshold', angle_diff / 2);
% Add noise to distances (proportional to the distance)
finite_ind = isfinite(depth);
finite_noise = sensor.range_standard_deviation * depth(finite_ind) .* randn(1, sum(finite_ind));
depth(finite_ind) = depth(finite_ind) + finite_noise;
% Consider lidar max range
max_range_ind = depth > sensor.max_range;
depth(max_range_ind) = inf;
% Take the minimum depth as one value (not array)
depth = min(depth);
end