function h = plot_error_ellipse(cov, mu, conf, col, np)
% -------------------------------------------------------------------------
% PLOT_ERROR_ELLIPSE    plot covariance error ellipse in 2D.
%
% Usage
%   h = PLOT_ERROR_ELLIPSE(cov, mu, conf, col, np);
%
% Parameters
%   cov     (2, 2)  Covariance matrix in 2D.
%   mu      (2, 1)  Mean in 2D.
%   conf    (1, 1)  Confidence percentage, e.g. 95%
%   col     (1, 1)  Color of the plot
%   np      (1, 1)  Number of points to use in plotting.
%
% Returns
%   h       (1, 1)  plot handle.
%
% Reference
%   https://www.visiondummy.com/2014/04/draw-error-ellipse-representing-covariance-matrix/
%
% Implementation
%   Mohamed Mustafa, December 2020
% -------------------------------------------------------------------------

% Default values
if nargin < 5
    np = 50;
    if nargin < 4
        col = 'b';
        if nargin < 3
            conf = 0.95;
            if nargin < 2
                mu = [0 0];
            end
        end
    end
end
% Make sure covariance is symmetric in 2D
[r, c] = size(cov);
dim_cond = (r == c) && (r == 2);
sym_cond = all_close(cov, cov');
if ~(dim_cond && sym_cond)
    error('Covariance matrix is either not symmetric or not in 2D')
end
% Compute ellipse scale using chi-square distribution
scale = chi2inv(conf, 2);
% Compute eigenvalues of cov
[V, D] = eig(cov);
d = diag(D);
m = min(d);
if is_close(m, 0)
    h = [];
    return
elseif m < 0
    error('Covariance matrix is not positive semi-definite!')
end
% Create ellipse around the origin using eigenvalues as radii
t = linspace(0, 2*pi, np);
pts = bsxfun(@times, sqrt(scale) * d, [cos(t); sin(t)]);
% Apply affine transformation using first eignevector for rotation and mean for translation
alpha = atan2(V(2, 1), V(1, 1));
c_a = cos(alpha);
s_a = sin(alpha);
pts = bsxfun(@plus, [c_a -s_a; s_a c_a] * pts, mu(:));
% Plot ellipse
h = plot(pts(1, :), pts(2, :), [col '-']);
end