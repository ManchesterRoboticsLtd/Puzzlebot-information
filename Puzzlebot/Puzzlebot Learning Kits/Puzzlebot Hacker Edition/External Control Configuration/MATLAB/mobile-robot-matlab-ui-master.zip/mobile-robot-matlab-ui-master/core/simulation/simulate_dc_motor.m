function state = simulate_dc_motor(sensor, initial_state, d_t, varargin)
% -------------------------------------------------------------------------
% SIMULATE_DC_MOTOR    find the new state of a DC motor based on its linear
% dynamical model.
%
% State is defined as [theta,  omega,  i] where:
%   - theta: angle of the shaft (radian)
%   - omega: angular velocity of the shaft (radian per second)
%   - i: electrical current in the armature (ampere)
%
% Simulation assumes a step input during timestep d_t.
%
% There are two types of input signal: `voltage_pwm` or `omega_setpoint`
% that are specified by `varargin` parameter. When voltage is selected the
% motor dynamics is simulated, whereas when selecting angular velocity
% (omega_setpoint) as input signal then motor steady state is considered.
%
% The voltage input is pulse width modulation duty cycle with range of 
% [-1, 1]
%
% If `sensor` has `gear_ratio` property then both `theta` and `omega`
% represent the output of the gearbox attached to the DC motor. Moreover
% `omega_setpoint` is also with respect to the output of the gearbox.
%
% Usage
%   state = SIMULATE_DC_MOTOR(sensor, initial_state, d_t, 'voltage_pwm', v_n);
%   state = SIMULATE_DC_MOTOR(sensor, initial_state, d_t, 'omega_setpoint', omega);
%
% Parameters
%   sensor          (1, 1)  ComponentClass object with type `dc-motor`
%   initial_state   (3, 1)  Initial state.
%   d_t             (1, 1)  Time interval size where input signal is
%                           assumed constant (step response).
%   varargin        (x, 1)  Structure that contains either `voltage_pwm`
%                           or `omega_setpoint` followed by the value.
%
% Returns
%   state           (3, 1)  New state after d_t seconds with step input
%                           signal.
%
% References
%   http://web.mit.edu/2.14/www/Handouts/StateSpaceResponse.pdf
%   http://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=ControlStateSpace
%
% Implementation
%   Mohamed Mustafa, August 2020
% -------------------------------------------------------------------------

% Sanity check
if ~strcmp(sensor.type, 'dc-motor')
    error(['Invalid sensor type (' sensor.type ')! Expected: dc-motor'])
end
% Construct state space matrices for angular velocity and electrical
% current. We cannot do all together with angle (theta) because A will
% become singular (not invertible)
try
    A = sensor.A;
    B = sensor.B;
catch
    A = [-sensor.b / sensor.J,      sensor.K / sensor.J;
        -sensor.K / sensor.L,      -sensor.R / sensor.L];
    B = [0;     1 / sensor.L];
    % Save as property for speed
    sensor.set_property('A', A)
    sensor.set_property('B', B)
end
% Decode input signal
parameters = varargin_to_parameters(varargin);
% Undo gear ratio action on angular velocity
try
    initial_state(2) = initial_state(2) * sensor.gear_ratio;
    parameters.omega_setpoint = parameters.omega_setpoint * sensor.gear_ratio;
catch
end
% Voltage input is prioritized if both input signal types are available
if isfield(parameters, 'voltage_pwm')
    % Make sure input voltage is between -1 and 1
    pwm_duty_cycle = clip(parameters.voltage_pwm, -1, 1);
    % Input step signal
    K = pwm_duty_cycle * sensor.v_max;
    % Closed form solution for step response only
    eAt = expm(A * d_t);
    state(2:3, 1) = eAt * initial_state(2:3) + A \ (eAt - eye(2)) * B * K;
elseif isfield(parameters, 'omega_setpoint')
    % Motor steady state for unit step pwm (max voltage)
    ss = -A \ B * sensor.v_max;     % [omega_ss,   i_ss]
    % Make sure the setpoint angular velocity is within possible range
    omega_setpoint = clip(parameters.omega_setpoint, -ss(1), ss(1));
    % Construct new linear system from A and B to solve for current i
    A_hat = [B, A(:, 2)];
    B_hat = A(:, 1);
    pwm_and_i = -A_hat \ B_hat * omega_setpoint;
    % Update the state
    state(2, 1) = omega_setpoint;
    state(3) = pwm_and_i(2);    
else
    error('Invalid input signal!')
end
% Apply gear ratio action on angular velocity
try
    state(2) = state(2) / sensor.gear_ratio;
    initial_state(2) = initial_state(2) / sensor.gear_ratio;
catch
end
% Compute theta from omega (trapezoidal rule for differential equations)
state(1) = initial_state(1) + (initial_state(2) + state(2)) / 2 * d_t;
end